<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
checkRole('patient');

$pageTitle = "My Bills - HealthManagement";
$extraCSS = '<link rel="stylesheet" href="../css/patient.css">';
include '../includes/header.php';

$userId = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT patientId FROM patients WHERE userId = ?");
$stmt->execute([$userId]);
$patient = $stmt->fetch();
if (!$patient) { 
    $_SESSION['error'] = "Profile not found."; 
    header("Location: dashboard.php"); 
    exit(); 
}
$patientId = $patient['patientId'];

$stmt = $pdo->prepare("
    SELECT b.*, CONCAT(u.firstName, ' ', u.lastName) as doctorName, mr.diagnosis
    FROM bills b 
    LEFT JOIN medical_records mr ON b.recordId = mr.recordId 
    LEFT JOIN doctors d ON mr.doctorId = d.doctorId
    LEFT JOIN staff s ON d.staffId = s.staffId 
    LEFT JOIN users u ON s.userId = u.userId 
    WHERE b.patientId = ? 
    ORDER BY b.generatedAt DESC
");
$stmt->execute([$patientId]);
$bills = $stmt->fetchAll();

$unpaidTotal = 0;
$paidTotal = 0;
foreach ($bills as $b) {
    if ($b['status'] == 'unpaid') $unpaidTotal += $b['totalAmount'];
    if ($b['status'] == 'paid') $paidTotal += $b['totalAmount'];
}
?>

<div class="patient-container">
    <div class="patient-page-header">
        <div class="header-title">
            <h1><i class="fas fa-file-invoice-dollar"></i> My Bills</h1>
            <p>View and manage your billing history</p>
        </div>
        <div class="header-actions">
            <a href="dashboard.php" class="patient-btn patient-btn-outline">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>

    <div class="patient-summary-cards">
        <div class="patient-summary-card">
            <span>Outstanding Balance</span>
            <span>$<?php echo number_format($unpaidTotal, 2); ?></span>
        </div>
        <div class="patient-summary-card">
            <span>Total Paid</span>
            <span>$<?php echo number_format($paidTotal, 2); ?></span>
        </div>
        <div class="patient-summary-card">
            <span>Total Bills</span>
            <span><?php echo count($bills); ?></span>
        </div>
    </div>

    <div class="patient-card">
        <div class="patient-card-header">
            <h3><i class="fas fa-list"></i> All Bills</h3>
        </div>
        <div class="patient-card-body">
            <?php if (empty($bills)): ?>
                <div class="patient-empty-state">
                    <i class="fas fa-receipt"></i>
                    <h3>No Bills Found</h3>
                    <p>You don't have any bills yet.</p>
                </div>
            <?php else: ?>
                <div class="patient-table-responsive">
                    <table class="patient-data-table">
                        <thead>
                            <tr>
                                <th>Bill #</th>
                                <th>Date</th>
                                <th>Doctor</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($bills as $b): ?>
                                <tr>
                                    <td data-label="Bill #">#<?php echo str_pad($b['billId'], 6, '0', STR_PAD_LEFT); ?></td>
                                    <td data-label="Date"><?php echo date('M j, Y', strtotime($b['generatedAt'])); ?></td>
                                    <td data-label="Doctor">Dr. <?php echo htmlspecialchars($b['doctorName']); ?></td>
                                    <td data-label="Amount">$<?php echo number_format($b['totalAmount'], 2); ?></td>
                                    <td data-label="Status">
                                        <span class="patient-status-badge patient-status-<?php echo $b['status']; ?>">
                                            <?php echo ucfirst($b['status']); ?>
                                        </span>
                                    </td>
                                    <td data-label="Actions">
                                        <a href="view-bill.php?bill_id=<?php echo $b['billId']; ?>" class="patient-btn patient-btn-info patient-btn-sm">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <?php if ($b['status'] == 'unpaid'): ?>
                                            <a href="view-bill.php?bill_id=<?php echo $b['billId']; ?>" class="patient-btn patient-btn-primary patient-btn-sm">
                                                <i class="fas fa-credit-card"></i> Pay
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>