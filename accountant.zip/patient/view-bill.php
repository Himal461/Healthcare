<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
checkRole('patient');

$pageTitle = "View Bill - HealthManagement";
$extraCSS = '<link rel="stylesheet" href="../css/patient.css">';
include '../includes/header.php';

$userId = $_SESSION['user_id'];
$billId = (int)($_GET['bill_id'] ?? 0);

if (!$billId) { 
    $_SESSION['error'] = "Bill ID required."; 
    header("Location: view-bills.php"); 
    exit(); 
}

$stmt = $pdo->prepare("SELECT patientId FROM patients WHERE userId = ?");
$stmt->execute([$userId]);
$patient = $stmt->fetch();
$patientId = $patient['patientId'];

$stmt = $pdo->prepare("
    SELECT b.*, CONCAT(u.firstName, ' ', u.lastName) as doctorName, d.specialization, 
           mr.diagnosis, mr.creationDate as consultationDate, a.dateTime as appointmentDate
    FROM bills b 
    LEFT JOIN medical_records mr ON b.recordId = mr.recordId 
    LEFT JOIN doctors d ON mr.doctorId = d.doctorId
    LEFT JOIN staff s ON d.staffId = s.staffId 
    LEFT JOIN users u ON s.userId = u.userId 
    LEFT JOIN appointments a ON b.appointmentId = a.appointmentId
    WHERE b.billId = ? AND b.patientId = ?
");
$stmt->execute([$billId, $patientId]);
$bill = $stmt->fetch();

if (!$bill) { 
    $_SESSION['error'] = "Bill not found."; 
    header("Location: view-bills.php"); 
    exit(); 
}

$stmt = $pdo->prepare("SELECT * FROM bill_charges WHERE billId = ?");
$stmt->execute([$billId]);
$additionalCharges = $stmt->fetchAll();

$paymentSuccess = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pay_bill'])) {
    $paymentMethod = $_POST['payment_method'] ?? '';
    if ($paymentMethod) {
        $stmt = $pdo->prepare("UPDATE bills SET status = 'paid', paidAt = NOW() WHERE billId = ? AND status = 'unpaid'");
        $stmt->execute([$billId]);
        if ($stmt->rowCount() > 0) {
            addFinanceTransaction('revenue', 'bill_payment', $bill['totalAmount'], $billId, "Bill payment received via {$paymentMethod}");
            sendPaymentConfirmationEmail($billId);
            createNotification($userId, 'billing', 'Payment Successful',
                "Your payment of $" . number_format($bill['totalAmount'], 2) . " for Bill #" . str_pad($billId, 6, '0', STR_PAD_LEFT) . " has been received.");
            $bill['status'] = 'paid';
            $bill['paidAt'] = date('Y-m-d H:i:s');
            $paymentSuccess = true;
        }
    }
}

$success = $_SESSION['success'] ?? null;
$error = $_SESSION['error'] ?? null;
unset($_SESSION['success'], $_SESSION['error']);
?>

<div class="patient-container">
    <div class="patient-page-header">
        <div class="header-title">
            <h1><i class="fas fa-receipt"></i> Bill Details</h1>
            <p>Bill #<?php echo str_pad($bill['billId'], 6, '0', STR_PAD_LEFT); ?></p>
        </div>
        <div class="header-actions">
            <a href="view-bills.php" class="patient-btn patient-btn-outline">
                <i class="fas fa-arrow-left"></i> Back
            </a>
            <button onclick="window.print()" class="patient-btn patient-btn-primary">
                <i class="fas fa-print"></i> Print
            </button>
        </div>
    </div>

    <?php if ($error): ?>
        <div class="patient-alert patient-alert-error">
            <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="patient-alert patient-alert-success">
            <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($paymentSuccess): ?>
        <div class="patient-alert patient-alert-success">
            <i class="fas fa-check-circle"></i> Payment Successful! A confirmation email has been sent.
        </div>
    <?php endif; ?>

    <div class="patient-bill-card">
        <div class="patient-bill-header">
            <div>
                <h2>HealthManagement System</h2>
                <p>Fussel Lane, Gungahlin, ACT 2912, Australia</p>
                <p>Phone: +61 438 347 3483</p>
            </div>
            <div class="patient-bill-info">
                <div class="patient-bill-number"><strong>Bill #:</strong> <?php echo str_pad($bill['billId'], 6, '0', STR_PAD_LEFT); ?></div>
                <p><strong>Date:</strong> <?php echo date('F j, Y', strtotime($bill['generatedAt'])); ?></p>
                <p>
                    <span class="patient-status-badge patient-status-<?php echo $bill['status']; ?>">
                        <?php echo ucfirst($bill['status']); ?>
                    </span>
                </p>
            </div>
        </div>

        <h3 style="color: #1e293b; margin-bottom: 20px;">Consultation Details</h3>
        <div style="background: #f8fafc; padding: 20px; border-radius: 12px; margin-bottom: 30px;">
            <p><strong>Doctor:</strong> Dr. <?php echo htmlspecialchars($bill['doctorName']); ?> (<?php echo $bill['specialization']; ?>)</p>
            <p><strong>Date:</strong> <?php echo date('F j, Y', strtotime($bill['consultationDate'])); ?></p>
            <?php if ($bill['diagnosis']): ?>
                <p><strong>Diagnosis:</strong> <?php echo nl2br(htmlspecialchars($bill['diagnosis'])); ?></p>
            <?php endif; ?>
        </div>

        <h3 style="color: #1e293b; margin-bottom: 20px;">Bill Summary</h3>
        <table class="patient-bill-table">
            <tr><td>Consultation Fee:</td><td>$<?php echo number_format($bill['consultationFee'], 2); ?></td></tr>
            <?php foreach ($additionalCharges as $c): ?>
                <tr><td><?php echo htmlspecialchars($c['chargeName']); ?>:</td><td>$<?php echo number_format($c['amount'], 2); ?></td></tr>
            <?php endforeach; ?>
            <tr><td>Service Charge (3%):</td><td>$<?php echo number_format($bill['serviceCharge'], 2); ?></td></tr>
            <tr><td>GST (13%):</td><td>$<?php echo number_format($bill['gst'], 2); ?></td></tr>
            <tr class="total-row"><td><strong>Total:</strong></td><td><strong>$<?php echo number_format($bill['totalAmount'], 2); ?></strong></td></tr>
        </table>

        <?php if ($bill['status'] == 'unpaid'): ?>
            <div class="patient-payment-section">
                <h3 style="color: #1e293b; margin-bottom: 20px;">Make Payment</h3>
                <form method="POST">
                    <div class="patient-form-group">
                        <label>Payment Method</label>
                        <select name="payment_method" class="patient-form-control" required>
                            <option value="">Select Payment Method</option>
                            <option value="credit_card">Credit Card</option>
                            <option value="debit_card">Debit Card</option>
                            <option value="cash">Cash at Counter</option>
                        </select>
                    </div>
                    <button type="submit" name="pay_bill" class="patient-btn patient-btn-success patient-btn-large">
                        <i class="fas fa-credit-card"></i> Pay $<?php echo number_format($bill['totalAmount'], 2); ?>
                    </button>
                </form>
            </div>
        <?php else: ?>
            <div class="patient-payment-section" style="background: #dcfce7;">
                <h3 style="color: #166534; margin-bottom: 15px;">Payment Information</h3>
                <p><span class="patient-status-badge patient-status-paid">Paid</span></p>
                <p><strong>Paid On:</strong> <?php echo date('F j, Y g:i A', strtotime($bill['paidAt'])); ?></p>
            </div>
        <?php endif; ?>

        <div class="patient-bill-footer">
            <p>Thank you for choosing HealthManagement System.</p>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>