<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

if (isLoggedIn()) {
    $role = $_SESSION['user_role'];
    
    // CRITICAL FIX: Proper role-based routing with switch statement
    switch ($role) {
        case 'admin':
            redirect('admin/dashboard.php');
            break;
        case 'doctor':
            redirect('doctor/dashboard.php');
            break;
        case 'nurse':
            redirect('nurse/dashboard.php');
            break;
        case 'staff':
            redirect('staff/dashboard.php');
            break;
        case 'accountant':
            redirect('accountant/dashboard.php');
            break;
        case 'patient':
            redirect('patient/dashboard.php');
            break;
        default:
            redirect('login.php');
            break;
    }
}

redirect('login.php');