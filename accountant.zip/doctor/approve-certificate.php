<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
checkRole('doctor');

$pageTitle = "Approve Medical Certificate - HealthManagement";
$extraCSS = '<link rel="stylesheet" href="../css/doctor.css">';
include '../includes/header.php';

$certificateId = (int)($_GET['id'] ?? 0);
$action = $_GET['action'] ?? '';
$doctorUserId = $_SESSION['user_id'];

// Get doctor ID - FIXED QUERY
$stmt = $pdo->prepare("
    SELECT d.doctorId, u.firstName, u.lastName 
    FROM doctors d
    JOIN staff s ON d.staffId = s.staffId
    JOIN users u ON s.userId = u.userId
    WHERE s.userId = ?
");
$stmt->execute([$doctorUserId]);
$doctor = $stmt->fetch();

if (!$doctor) {
    $_SESSION['error'] = "Doctor profile not found. User ID: " . $doctorUserId;
    header("Location: dashboard.php");
    exit();
}

$doctorId = $doctor['doctorId'];

// Debug: Check if certificate exists at all
$checkStmt = $pdo->prepare("SELECT * FROM medical_certificates WHERE certificate_id = ?");
$checkStmt->execute([$certificateId]);
$anyCertificate = $checkStmt->fetch();

if (!$anyCertificate) {
    $_SESSION['error'] = "Certificate ID #{$certificateId} not found in database.";
    header("Location: dashboard.php");
    exit();
}

// Get certificate details - check both with and without doctor_id match
$stmt = $pdo->prepare("
    SELECT mc.*, 
           CONCAT(u.firstName, ' ', u.lastName) as patient_name,
           u.email as patient_email,
           p.patientId,
           p.userId as patient_user_id
    FROM medical_certificates mc
    JOIN patients p ON mc.patient_id = p.patientId
    JOIN users u ON p.userId = u.userId
    WHERE mc.certificate_id = ?
");
$stmt->execute([$certificateId]);
$certificate = $stmt->fetch();

if (!$certificate) {
    $_SESSION['error'] = "Certificate patient data not found.";
    header("Location: dashboard.php");
    exit();
}

// Check if this certificate is assigned to this doctor
if ($certificate['doctor_id'] != $doctorId) {
    $_SESSION['error'] = "This certificate is assigned to a different doctor (Doctor ID: {$certificate['doctor_id']}, You are Doctor ID: {$doctorId}).";
    header("Location: dashboard.php");
    exit();
}

// Check approval status
if (!isset($certificate['approval_status'])) {
    // Add the column if it doesn't exist in the result
    $certificate['approval_status'] = 'pending';
}

// Handle approval/rejection
if ($action === 'approve' && $certificate['approval_status'] === 'pending') {
    try {
        $pdo->beginTransaction();
        
        // Update certificate status
        $stmt = $pdo->prepare("
            UPDATE medical_certificates 
            SET approval_status = 'approved', 
                approved_at = NOW(), 
                approved_by = ?
            WHERE certificate_id = ?
        ");
        $stmt->execute([$doctorUserId, $certificateId]);
        
        // Generate PDF
        $pdfPath = generateMedicalCertificatePDF($certificateId);
        
        // Send email to patient with certificate
        $subject = "Your Medical Certificate is Ready - " . SITE_NAME;
        $message = "
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                    .header { background: #10b981; color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                    .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
                    .certificate-info { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
                    .button { display: inline-block; background: #10b981; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; }
                </style>
            </head>
            <body>
                <div class='container'>
                    <div class='header'>
                        <h2>✓ Medical Certificate Approved</h2>
                    </div>
                    <div class='content'>
                        <p>Dear <strong>{$certificate['patient_name']}</strong>,</p>
                        <p>Your medical certificate request has been approved by Dr. {$doctor['firstName']} {$doctor['lastName']}.</p>
                        <div class='certificate-info'>
                            <p><strong>Certificate #:</strong> {$certificate['certificate_number']}</p>
                            <p><strong>Period:</strong> " . date('M j, Y', strtotime($certificate['start_date'])) . " - " . date('M j, Y', strtotime($certificate['end_date'])) . "</p>
                        </div>
                        <p>The medical certificate is attached to this email.</p>
                        <p>Thank you for choosing HealthManagement System.</p>
                    </div>
                </div>
            </body>
            </html>
        ";
        sendEmailWithAttachment($certificate['patient_email'], $subject, $message, $pdfPath, "Medical_Certificate_{$certificate['certificate_number']}.html");
        
        // Create notification for patient
        if ($certificate['patient_user_id']) {
            createNotification(
                $certificate['patient_user_id'], 
                'medical_certificate', 
                'Certificate Approved', 
                "Your medical certificate #{$certificate['certificate_number']} has been approved by Dr. {$doctor['firstName']} {$doctor['lastName']} and sent to your email.",
                "../patient/my-medical-records.php"
            );
        }
        
        $pdo->commit();
        
        $_SESSION['success'] = "Certificate #{$certificate['certificate_number']} approved and sent to patient successfully!";
        logAction($doctorUserId, 'APPROVE_CERTIFICATE', "Approved certificate #{$certificate['certificate_number']}");
        
        header("Location: dashboard.php");
        exit();
        
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = "Failed to approve certificate: " . $e->getMessage();
        error_log("Certificate approval error: " . $e->getMessage());
        header("Location: dashboard.php");
        exit();
    }
    
} elseif ($action === 'reject' && $certificate['approval_status'] === 'pending') {
    $stmt = $pdo->prepare("
        UPDATE medical_certificates 
        SET approval_status = 'rejected', 
            approved_at = NOW(), 
            approved_by = ?
        WHERE certificate_id = ?
    ");
    $stmt->execute([$doctorUserId, $certificateId]);
    
    // Send rejection email
    $subject = "Medical Certificate Request Update - " . SITE_NAME;
    $message = "
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: #ef4444; color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
                .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>
                    <h2>Medical Certificate Request Update</h2>
                </div>
                <div class='content'>
                    <p>Dear {$certificate['patient_name']},</p>
                    <p>Your medical certificate request #{$certificate['certificate_number']} has been reviewed but could not be approved at this time.</p>
                    <p>Please contact our office for more information or schedule an appointment with Dr. {$doctor['firstName']} {$doctor['lastName']}.</p>
                    <p>Phone: +61 438 347 3483</p>
                </div>
            </div>
        </body>
        </html>
    ";
    sendEmail($certificate['patient_email'], $subject, $message);
    
    // Notify patient
    if ($certificate['patient_user_id']) {
        createNotification(
            $certificate['patient_user_id'], 
            'medical_certificate', 
            'Certificate Request Update', 
            "Your medical certificate request #{$certificate['certificate_number']} requires further attention. Please contact the office."
        );
    }
    
    $_SESSION['success'] = "Certificate #{$certificate['certificate_number']} rejected. Patient has been notified.";
    logAction($doctorUserId, 'REJECT_CERTIFICATE', "Rejected certificate #{$certificate['certificate_number']}");
    
    header("Location: dashboard.php");
    exit();
}

// Display certificate details for review
$certificateTypes = [
    'work' => 'Work Leave',
    'school' => 'School/University Leave',
    'travel' => 'Travel Cancellation',
    'insurance' => 'Insurance Claim',
    'other' => 'Other'
];

// Check if already processed
if ($certificate['approval_status'] !== 'pending') {
    $statusText = $certificate['approval_status'] === 'approved' ? 'Approved' : 'Rejected';
    $statusColor = $certificate['approval_status'] === 'approved' ? '#10b981' : '#ef4444';
    ?>
    <div class="doctor-container">
        <div class="doctor-page-header">
            <div class="header-title">
                <h1><i class="fas fa-file-medical"></i> Medical Certificate</h1>
                <p>Certificate #<?php echo $certificate['certificate_number']; ?></p>
            </div>
            <div class="header-actions">
                <a href="dashboard.php" class="doctor-btn doctor-btn-outline">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
        </div>
        
        <div class="doctor-card">
            <div class="doctor-card-body">
                <div class="doctor-alert doctor-alert-info">
                    <i class="fas fa-info-circle"></i>
                    This certificate has already been <strong><?php echo $statusText; ?></strong>.
                </div>
                <a href="dashboard.php" class="doctor-btn doctor-btn-primary">Return to Dashboard</a>
            </div>
        </div>
    </div>
    <?php
    include '../includes/footer.php';
    exit();
}
?>

<div class="doctor-container">
    <div class="doctor-page-header">
        <div class="header-title">
            <h1><i class="fas fa-file-medical"></i> Review Medical Certificate</h1>
            <p>Certificate #<?php echo $certificate['certificate_number']; ?></p>
        </div>
        <div class="header-actions">
            <a href="dashboard.php" class="doctor-btn doctor-btn-outline">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>

    <div class="doctor-card">
        <div class="doctor-card-header">
            <h3><i class="fas fa-info-circle"></i> Certificate Information</h3>
            <span class="doctor-status-badge" style="background: #fef3c7; color: #92400e;">Pending Approval</span>
        </div>
        <div class="doctor-card-body">
            <div class="doctor-patient-info-grid">
                <div class="doctor-info-group">
                    <h4>Patient Information</h4>
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($certificate['patient_name']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($certificate['patient_email']); ?></p>
                </div>
                <div class="doctor-info-group">
                    <h4>Certificate Details</h4>
                    <p><strong>Type:</strong> <?php echo $certificateTypes[$certificate['certificate_type']] ?? $certificate['certificate_type']; ?></p>
                    <p><strong>Period:</strong> <?php echo date('M j, Y', strtotime($certificate['start_date'])) . ' - ' . date('M j, Y', strtotime($certificate['end_date'])); ?></p>
                    <p><strong>Amount Paid:</strong> $<?php echo number_format($certificate['amount_paid'], 2); ?></p>
                    <p><strong>Payment Method:</strong> <?php echo ucfirst($certificate['payment_method'] ?? 'N/A'); ?></p>
                </div>
            </div>
            
            <h4 style="margin-top: 25px;">Medical Condition / Reason</h4>
            <div style="background: #f8fafc; padding: 20px; border-radius: 12px; line-height: 1.6;">
                <?php echo nl2br(htmlspecialchars($certificate['medical_condition'])); ?>
            </div>
            
            <?php if (!empty($certificate['additional_notes'])): ?>
                <h4 style="margin-top: 25px;">Additional Notes</h4>
                <div style="background: #f8fafc; padding: 20px; border-radius: 12px;">
                    <?php echo nl2br(htmlspecialchars($certificate['additional_notes'])); ?>
                </div>
            <?php endif; ?>
            
            <div style="display: flex; gap: 15px; margin-top: 30px; flex-wrap: wrap;">
                <a href="?id=<?php echo $certificateId; ?>&action=approve" class="doctor-btn doctor-btn-success" onclick="return confirm('Approve this medical certificate? The patient will receive the certificate via email.')">
                    <i class="fas fa-check"></i> Approve Certificate
                </a>
                <a href="?id=<?php echo $certificateId; ?>&action=reject" class="doctor-btn doctor-btn-danger" onclick="return confirm('Reject this medical certificate? The patient will be notified.')">
                    <i class="fas fa-times"></i> Reject Certificate
                </a>
                <a href="dashboard.php" class="doctor-btn doctor-btn-outline">Cancel</a>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>